import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'local-storage',
  templateUrl: './local-storage.component.html',
  styleUrls: ['./local-storage.component.css']
})
export class LocalStorageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
