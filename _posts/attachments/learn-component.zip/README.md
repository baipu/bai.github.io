# LearnComponent
这是一个教学项目，用来教Angular初学者如何写组件。

分支上的内容：

- template分支，用12个例子全面示范Angular的模板语法
- communication分支，示范组件之间的通讯
- hooks分支，示范组件的生命周期玩法
